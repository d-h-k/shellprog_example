#include <stdio.h>
#include "ArrayList.h"

int main(void)
{
	List list;
	int data;
	ListInit(&list);

	LInsert(&list, 11);  
	LInsert(&list, 11);
	LInsert(&list, 22);  
	LInsert(&list, 22);
	LInsert(&list, 33);

	/*** print data***/
	printf("Number of data : %d \n", LCount(&list));

	if(LFirst(&list, &data))    // 
	{
		printf("%d ", data);
		
		while(LNext(&list, &data))   
			printf("%d ", data);
	}
	printf("\n\n");





	/*** num 22 delete ***/
	if(LFirst(&list, &data))
	{
		if(data == 22) {
			LRemove(&list);
			puts("Delete num==22 ");
		}
		
		while(LNext(&list, &data))
		{
			if(data == 22) {
				LRemove(&list);
				puts("Delete num==22 ");
			}
		}
	}
	puts("");



	/*** After Delete***/
	printf("after delete all 22: %d \n", LCount(&list));

	if(LFirst(&list, &data))
	{
		printf("%d ", data);
		
		while(LNext(&list, &data))
			printf("%d ", data);
	}
	printf("\n\n");
	return 0;
}
