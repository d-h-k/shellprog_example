#include <stdio.h>
int main() {
	int a=0;

	if(a) {
		printf("hello world!!");
	}
	else {
		printf("World! halo");
	}

	return 0;
}

